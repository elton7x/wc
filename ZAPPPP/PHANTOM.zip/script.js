const presenters = [
    { name: "Patrícia Pacheco", image: "images/patricia_pacheco.webp" },
    { name: "Daniel Nascimento", image: "images/daniel_nascimento.webp" },
    { name: "Da Wanny", image: "images/da_wanny.webp" },
    { name: "Carla Djamila", image: "images/carla_djamila.webp" },
    { name: "Job Paiva", image: "images/job_paiva.webp" },
    { name: "Indira Silva", image: "images/indira_silva.webp" },
    { name: "Márcio Stélvio", image: "images/Marcio_stelvio.webp" },
    { name: "Whitney Shikongo", image: "images/whitney_shikongo.webp" }
];

let currentIndex = 0;
let earnings = 0;
const EARNINGS_PER_STEP = 10000;
let currentRating = 0;
let currentKnown = null;
const cashSound = new Audio('sounds/cash.mp3');

// DOM Elements
const appContent = document.getElementById('app-content');
const earningsContainer = document.getElementById('earnings-container');
const progressContainer = document.getElementById('progress-container');
const earningsDisplay = document.getElementById('earnings-display');
const progressBar = document.getElementById('progress-bar');

function formatCurrency(amount) {
    return amount.toLocaleString('pt-AO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " Kzs";
}

function updateHeader() {
    earningsDisplay.textContent = formatCurrency(earnings);
    const progress = (currentIndex / presenters.length) * 100;
    progressBar.style.width = `${progress}%`;
}

// 1. Intro Screen
function showIntro() {
    if (earningsContainer) earningsContainer.classList.add('hidden');
    if (progressContainer) progressContainer.classList.add('hidden');

    appContent.innerHTML = `
        <div class="card-content animate-entry">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSk6QraYDzsP3ZwJEgU_b9Do-MculOzHnAcQw&s" alt="ZAP Logo" class="intro-logo">
            <h1 class="intro-title">Parabéns!</h1>
            <p class="intro-text">
                Este é um programa oficial da <strong>ZAP</strong>.<br>
                Você foi selecionado para participar da nossa pesquisa exclusiva de audiência.
                <br><br>
                Aproveite esta chance única de avaliar nossos apresentadores e tenha <strong>bons ganhos</strong> instantâneos!
            </p>
            <button class="btn-action" onclick="startQuiz()">
                Começar Agora
            </button>
        </div>
    `;
}

window.startQuiz = () => {
    earningsContainer.classList.remove('hidden');
    progressContainer.classList.remove('hidden');
    renderCard();
};

// 2. Quiz Logic
function renderCard() {
    if (currentIndex >= presenters.length) {
        showWithdrawalSelection();
        return;
    }

    const presenter = presenters[currentIndex];

    appContent.innerHTML = `
        <div class="card-content animate-entry">
            <div class="presenter-img-container">
                <img src="${presenter.image}" alt="${presenter.name}" class="presenter-img">
            </div>
            <h2 class="presenter-name">${presenter.name}</h2>
            
            <div class="question-block" style="width:100%">
                <p class="intro-text">Você conhece est${presenter.name.endsWith('a') ? 'a' : 'e'} apresentador${presenter.name.endsWith('a') ? 'a' : ''}?</p>
                <div class="btn-group">
                    <button class="btn-option" onclick="setKnown(true, this)">Sim</button>
                    <button class="btn-option" onclick="setKnown(false, this)">Não</button>
                </div>
            </div>

            <div class="question-block" style="width:100%">
                <p class="intro-text">Que nota daria?</p>
                <div class="star-rating">
                    <input type="radio" id="star5" name="rating" value="5" onclick="setRating(5)"><label for="star5">★</label>
                    <input type="radio" id="star4" name="rating" value="4" onclick="setRating(4)"><label for="star4">★</label>
                    <input type="radio" id="star3" name="rating" value="3" onclick="setRating(3)"><label for="star3">★</label>
                    <input type="radio" id="star2" name="rating" value="2" onclick="setRating(2)"><label for="star2">★</label>
                    <input type="radio" id="star1" name="rating" value="1" onclick="setRating(1)"><label for="star1">★</label>
                </div>
            </div>

            <button id="btn-next" class="btn-action" disabled onclick="submitRating()">
                Avaliar e Ganhar ${formatCurrency(EARNINGS_PER_STEP)}
            </button>
        </div>
    `;

    // Reset state
    currentKnown = null;
    currentRating = 0;
}

window.setKnown = (known, btn) => {
    currentKnown = known;
    const buttons = btn.parentElement.querySelectorAll('.btn-option');
    buttons.forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    checkFormCompletion();
};

window.setRating = (rating) => {
    currentRating = rating;
    checkFormCompletion();
};

function checkFormCompletion() {
    const btnNext = document.getElementById('btn-next');
    if (currentKnown !== null && currentRating > 0) {
        btnNext.disabled = false;
    }
}

window.submitRating = () => {
    const btnNext = document.getElementById('btn-next');

    cashSound.currentTime = 0; // Reset sound to start
    cashSound.play().catch(e => console.log("Audio play failed:", e)); // Catch interaction errors

    earnings += EARNINGS_PER_STEP;
    updateHeader();

    btnNext.textContent = "Avaliado! +10.000 Kzs";
    btnNext.style.background = "var(--success)";
    btnNext.style.color = "#000";

    // Float animation
    const float = document.createElement('div');
    float.classList.add('money-float');
    float.textContent = "+ 10.000 Kzs";
    float.style.left = '50%';
    float.style.top = '50%';
    float.style.transform = 'translate(-50%, -50%)';
    appContent.appendChild(float);

    setTimeout(() => {
        currentIndex++;
        updateHeader();
        renderCard();
    }, 1200);
};

// 3. Withdrawal Selection
function showWithdrawalSelection() {
    progressContainer.classList.add('hidden'); // Hide progress bar at the end
    appContent.innerHTML = `
        <div class="card-content animate-entry">
            <h2 class="presenter-name">Saque Disponível</h2>
            <p class="intro-text">Saldo Total: <strong style="color:var(--zap-yellow)">${formatCurrency(earnings)}</strong></p>
            
            <div class="withdrawal-options">
                <div class="withdrawal-card" onclick="showInputScreen('Express')">
                    <span class="withdrawal-icon">⚡</span>
                    <div>
                        <strong>Transferência Express</strong><br>
                        <small style="color:var(--text-muted)">Receba em 5 minutos</small>
                    </div>
                </div>
                
                <div class="withdrawal-card" onclick="showInputScreen('IBAN')">
                    <span class="withdrawal-icon">🏦</span>
                    <div>
                        <strong>Transferência Bancária (IBAN)</strong><br>
                        <small style="color:var(--text-muted)">24 a 48 horas úteis</small>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// 4. Processing & Fee Message
window.showInputScreen = (method) => {
    const label = method === 'Express' ? 'Número de Telefone' : 'IBAN';
    const placeholder = method === 'Express' ? '9XX XXX XXX' : 'AO06 ...';
    const inputType = method === 'Express' ? 'tel' : 'text';

    appContent.innerHTML = `
        <div class="card-content animate-entry">
            <h2 class="presenter-name">Dados para Saque</h2>
            <p class="intro-text">Insira seu ${label} para receber <strong>${formatCurrency(earnings)}</strong></p>
            
            <div class="question-block" style="width:100%">
                <input type="${inputType}" id="withdraw-input" class="input-field" placeholder="${placeholder}" style="width: 100%; padding: 15px; border-radius: 12px; border: 1px solid var(--glass-border); background: rgba(255,255,255,0.1); color: white; margin-bottom: 20px; font-size: 1rem; outline: none;">
            </div>

            <button class="btn-action" onclick="confirmWithdrawal('${method}')">
                Sacar
            </button>
        </div>
    `;
};

window.confirmWithdrawal = (method) => {
    const input = document.getElementById('withdraw-input').value;
    if (!input) {
        alert('Por favor, preencha o campo.');
        return;
    }

    appContent.innerHTML = `
        <div class="card-content animate-entry">
            <h2 class="presenter-name">Processando...</h2>
            <div class="spinner"></div>
            <p class="intro-text">Verificando dados para transferência ${method}...</p>
        </div>
    `;

    // Simulate Fake Processing Time (4 seconds)
    setTimeout(() => {
        showFeeError();
    }, 4000);
};

function showFeeError() {
    appContent.innerHTML = `
        <div class="card-content animate-entry">
            <h2 class="presenter-name" style="color: var(--danger)">⚠️ Atenção Necessária</h2>
            <p class="intro-text">
                Sua conta não está cadastrada em nosso sistema de pagamentos automáticos.
            </p>
            
            <div class="alert-box">
                <strong>Verificação Pendente</strong><br>
                Devido a tentativas de fraude recentes, é necessário realizar uma verificação de identidade.
            </div>

            <p class="intro-text" style="margin-top:20px">
                Para liberar seu saque de <strong>${formatCurrency(earnings)}</strong>, pague a taxa única de verificação:
            </p>

            <h1 class="presenter-name" style="font-size:2.5rem; margin: 10px 0;">4.500 Kzs</h1>

            <button class="btn-action" onclick="alert('Abrir vídeo explicativo...')">
                VER VÍDEO EXPLICATIVO
            </button>
        </div>
    `;
}

// Initialize
updateHeader();
showIntro();

// Set current date in offer banner
const dateElement = document.getElementById('current-date');
if (dateElement) {
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    dateElement.textContent = `${day}/${month}/${year}`;
}
